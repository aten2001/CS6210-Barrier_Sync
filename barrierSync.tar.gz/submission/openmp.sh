#PBS -q cs6210
#PBS -l nodes=1:fourcore
#PBS -l walltime=00:01:00
#PBS -N Tournament
/nethome/hchawla7/CS6210-Barrier_Sync/OpenMP/Tournament 8 10
